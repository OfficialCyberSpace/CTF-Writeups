import os
from pwn import *

bytes = os.urandom(2)

pr = process('./digital-seconds-ago')
for i in range(0,7):
	print(pr.recvline())
#print(pr.recvall())
print(pr.recvuntil(b'$'))
print(pr.send('login\n'))
print(pr.send('user\n'))
#print(pr.send(b'user'))
print(pr.recvuntil('challenge:'))
chal = pr.recvline().strip()
print(chal)
