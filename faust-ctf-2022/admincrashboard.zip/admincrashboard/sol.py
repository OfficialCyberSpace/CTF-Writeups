import requests
host = '\[fd66:666:873::2\]'
url = host + ":5000/edit?button=/home/mrex11/welcome.button'
headers = { "Content-Type": "text/plain" }
body = 
