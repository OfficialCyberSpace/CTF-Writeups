# Fitty Fit
A platform to create and exchange non forgeable trainingplans (NFTs).

## Setup
The platform uses Docker. Using `docker-compose`, it is easy to run the server.
```
docker-compose up --build
```

## TODOs
It seems that our intern did not know about security and introduced some vulnerabilities.
We already fixed some issues, yet, due tight to deadlines we were not able to review the entire code.
Surely, our application contains more bugs that we must find and address asap!
Furthermore, we would like to move the entire project to a more up-to-date Python version, but for some reason it did not work...
