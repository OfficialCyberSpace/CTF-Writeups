package de.faust.compiler60.ir;

import de.faust.compiler60.types.Type;

public abstract class IROperand {
  public abstract Type getType();
}
