package de.faust.compiler60.ast;

public abstract class BooleanExpression extends ASTNode {
  public BooleanExpression(int lineNumber) {
    super(lineNumber);
  }
}
