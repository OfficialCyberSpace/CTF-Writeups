package de.faust.compiler60.ast;

public abstract class Statement extends ASTNode {
  public Statement(int lineNumber) {
    super(lineNumber);
  }
}
